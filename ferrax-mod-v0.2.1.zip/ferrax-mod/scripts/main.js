// FERRAX MOD — main.js
// В HJSON-модах конструктор юнитов нельзя задать в .hjson файле.
// Он задаётся только через JavaScript.
// UnitEntity::new — для наземных и морских (шлаковых) юнитов.
// ElevationMoveUnit::new (или UnitEntity::new) — для летающих.

const UnitEntity = Packages.mindustry.entities.units.UnitEntity;

// Список всех юнитов мода и их конструкторы
const unitDefs = [
    // Наземные
    ["ferrax-walker-t1",    UnitEntity.new],
    ["ferrax-crawler-t2",   UnitEntity.new],
    ["ferrax-crusher-t3",   UnitEntity.new],
    ["ferrax-siege-t4",     UnitEntity.new],
    ["ferrax-titan-t5",     UnitEntity.new],
    // Воздушные
    ["ferrax-drone-t1",     UnitEntity.new],
    ["ferrax-striker-t2",   UnitEntity.new],
    ["ferrax-raptor-t3",    UnitEntity.new],
    ["ferrax-wing-t4",      UnitEntity.new],
    ["ferrax-void-t5",      UnitEntity.new],
    // Шлаковые (морские)
    ["ferrax-slagger-t1",   UnitEntity.new],
    ["ferrax-floater-t2",   UnitEntity.new],
    ["ferrax-dredge-t3",    UnitEntity.new],
    ["ferrax-barge-t4",     UnitEntity.new],
    ["ferrax-leviathan-t5", UnitEntity.new],
];

Events.on(ClientLoadEvent, () => {
    unitDefs.forEach(([name, ctor]) => {
        const unit = Vars.content.unit(name);
        if (unit !== null) {
            unit.constructor = ctor;
        } else {
            Log.warn("[Ferrax] Unit not found: " + name);
        }
    });
});
